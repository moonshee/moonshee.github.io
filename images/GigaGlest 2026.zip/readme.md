GigaGlest 2026
--------------
Developed jointly in California and Japan
Feather Hollow Engineering
Kagaku International
Moonshee Worldwide
Iowa AI
Dr. Fujihara

Release Sept. 2026, Tokyo Japan
-------------------------------

Instructions:
Decompress
Play it in browser like Safari or Edge
Works on almost any system even a smartphone or 32-bit older pc
iPad 2 not supported


Walkthrough:
Click on Start
Optional:
	Click on Settings
	Select your map and team, opponents, settings
	Click on Save
Click on Crypto
Click on Barter
Click on Real Estate
Buy Land
Click on Fiber Optics
To defeat the challenge just keep clicking the targets
	you will win eventually
Click on Substation
Click around to make time go by faster which increases your crypto total
	Cryto goes up over time against the Euro and also you get extra
	coins by staking and doing 100-1 swap drops and rewards.  That part
	is automated so once the player has 100 coins they will grow into 200
	but it takes time.
Click on Data Centers to build more

Avoid clicking on Robots or signing P.O.
Avoid negotiating with poachers and enemies
Avoid using a high skill level in settings - that is for experts only.
If you click on the CHEAT option in SETTINGS that can help newbies by giving
	the player a head start on resources and staff